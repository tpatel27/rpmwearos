package com.crazy_coder.everfit_wear.data.model

data class DataWorkout(val avgHeart: String?, val distanceTotal: String?, val calories: String?)
