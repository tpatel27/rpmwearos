package com.crazy_coder.everfit_wear.data.model

data class EventWorkout(val title: String?, val event: String?, val hasKey: Long)
