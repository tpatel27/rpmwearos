package com.ishantejas.accbtproj.data.mapper

class DomainToNetwork {
}