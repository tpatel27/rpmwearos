package com.ishantejas.accbtproj.data.model

data class Exercise(val name: String, val description: String, val durationInSeconds: Int , val gifImageUrl : String)
