package com.ishantejas.accbtproj.data.response

data class HeartDataResponse(
    val message : String
)