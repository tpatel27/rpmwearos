package com.ishantejas.accbtproj.data.model

data class Rest(val name: String, val durationInSeconds: Int, val gifImageUrl : String)
