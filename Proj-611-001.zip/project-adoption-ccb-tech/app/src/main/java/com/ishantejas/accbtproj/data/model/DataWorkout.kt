package com.ishantejas.accbtproj.data.model

data class DataWorkout(val avgHeart: String?, val distanceTotal: String?, val calories: String?)
